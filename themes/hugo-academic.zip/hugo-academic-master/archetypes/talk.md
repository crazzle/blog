+++
title = "{{ replace .TranslationBaseName "-" " " | title }}"
date = {{ .Date }}
draft = false

abstract = ""
abstract_short = ""
event = ""
event_url = ""
location = ""

selected = false
math = false
highlight = true

url_pdf = ""
url_slides = ""
url_video = ""

# Featured image
# Place your image in the `static/img/` folder and reference its filename below, e.g. `image = "example.jpg"`.
[header]
image = ""
caption = ""

+++
