+++
# Selected Publications widget.
# This widget displays publications from `content/publication/` which have
# `selected = true` in their `+++` front matter.

date = 2016-04-20
draft = false

title = "Selected Publications"
subtitle = ""
widget = "publications_selected"

# Order that this section will appear in.
weight = 10

# List format.
#   0 = Simple
#   1 = Classic
#   2 = Detailed
list_format = 2

+++

