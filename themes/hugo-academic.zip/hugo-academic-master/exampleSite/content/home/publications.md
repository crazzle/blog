+++
# Recent Publications widget.
# This widget displays recent publications from `content/publication/`.

date = 2016-04-20
draft = false

title = "Recent Publications"
subtitle = ""
widget = "publications"

# Order that this section will appear in.
weight = 20

# Number of publications to list.
count = 10

# List format.
#   0 = Simple
#   1 = Classic
#   2 = Detailed
list_format = 0

+++

