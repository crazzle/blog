+++
# Recent Posts widget.
# This widget displays recent posts from `content/post/`.

date = "2016-04-20T00:00:00"
draft = false

title = "Recent Posts"
subtitle = ""
widget = "posts"

# Order that this section will appear in.
weight = 40

# Show posts that contain the following tags. Default to any tags.
tags = []

# Number of posts to list.
count = 5

+++

